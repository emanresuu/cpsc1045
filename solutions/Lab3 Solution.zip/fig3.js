//Get reference to the canvas
var canvas = document.getElementById("ds1");
var ctx = canvas.getContext("2d");

//Starship
ctx.save();
ctx.translate(20, 0);
ctx.beginPath();

//saucer
ctx.lineTo(0, 100);
ctx.lineTo(30, 85);
ctx.lineTo(80, 85);
ctx.lineTo(110, 100);
ctx.lineTo(110, 110);
ctx.lineTo(80, 125);
ctx.lineTo(30, 125);
ctx.lineTo(0, 110);
ctx.lineTo(0, 100);
ctx.stroke();

//connection
ctx.beginPath();
ctx.lineTo(80, 125);
ctx.lineTo(110, 150);
ctx.stroke();

//connection
ctx.beginPath();
ctx.lineTo(95, 117.5);
ctx.lineTo(125, 150);
ctx.stroke();

//tube
ctx.fillRect(110, 150, 100, 20);

ctx.beginPath();
ctx.lineTo(160, 150);
ctx.lineTo(180, 125);
ctx.stroke();

ctx.beginPath();
ctx.lineTo(190, 150);
ctx.lineTo(210, 125);
ctx.stroke();

//Nacelle
ctx.fillRect(180, 110, 60, 15);
ctx.restore();

//Flower
//Get reference to the canvas
canvas = document.getElementById("ds2");
ctx = canvas.getContext("2d");
ctx.translate(canvas.height / 2, canvas.width / 2);
ctx.save();
//leaf
ctx.beginPath();
ctx.lineTo(0, 0);
ctx.lineTo(30, 20);
ctx.lineTo(70, 20);
ctx.lineTo(100, 0);
ctx.lineTo(70, -20);
ctx.lineTo(30, -20);
ctx.lineTo(0, 0);
ctx.lineTo(100, 0);
ctx.stroke();

ctx.rotate(72 * Math.PI / 180);
ctx.beginPath();
ctx.lineTo(0, 0);
ctx.lineTo(30, 20);
ctx.lineTo(70, 20);
ctx.lineTo(100, 0);
ctx.lineTo(70, -20);
ctx.lineTo(30, -20);
ctx.lineTo(0, 0);
ctx.lineTo(100, 0);
ctx.stroke();

ctx.rotate(72 * Math.PI / 180);
ctx.beginPath();
ctx.lineTo(0, 0);
ctx.lineTo(30, 20);
ctx.lineTo(70, 20);
ctx.lineTo(100, 0);
ctx.lineTo(70, -20);
ctx.lineTo(30, -20);
ctx.lineTo(0, 0);
ctx.lineTo(100, 0);
ctx.stroke();

ctx.rotate(72 * Math.PI / 180);
ctx.beginPath();
ctx.lineTo(0, 0);
ctx.lineTo(30, 20);
ctx.lineTo(70, 20);
ctx.lineTo(100, 0);
ctx.lineTo(70, -20);
ctx.lineTo(30, -20);
ctx.lineTo(0, 0);
ctx.lineTo(100, 0);
ctx.stroke();

ctx.rotate(72 * Math.PI / 180);
ctx.beginPath();
ctx.lineTo(0, 0);
ctx.lineTo(30, 20);
ctx.lineTo(70, 20);
ctx.lineTo(100, 0);
ctx.lineTo(70, -20);
ctx.lineTo(30, -20);
ctx.lineTo(0, 0);
ctx.lineTo(100, 0);
ctx.stroke();
ctx.restore();
ctx.beginPath();
ctx.arc(0, 0, 15, 0, 2 * Math.PI);
ctx.fill();

//Get reference to the canvas
canvas = document.getElementById("ds3");
ctx = canvas.getContext("2d");

ctx.translate(canvas.height / 2, canvas.width / 2);
ctx.beginPath();
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.rotate(45 * Math.PI / 180);
ctx.lineTo(50, 0);
ctx.stroke();