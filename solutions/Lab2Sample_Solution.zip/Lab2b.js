//Question 1
var q1Out = document.getElementById("question1");
var a1Out = document.getElementById("answer1");

var pies = Math.floor(Math.random() * 10) + 10;
var eatenPies = Math.floor(Math.random() * 10) + 1;

q1Out.innerHTML = "You have " + pies + " and you eat " + eatenPies +
    " how many pies do you have left.";
a1Out.innerHTML = "Answer " + (pies - eatenPies);

//Question 2
var q2Out = document.getElementById("question2");
var a2Out = document.getElementById("answer2");

var num1 = Math.floor(Math.random() * 10) + 1;
var num2 = Math.floor(Math.random() * 10) + 1;

q2Out.innerHTML = "What is the product of " + num1 + " and " + num2;
a2Out.innerHTML = "Answer " + num1 * num2;

//Question 3
var q3Out = document.getElementById("question3");
var a3Out = document.getElementById("answer3");

num1 = Math.floor(Math.random() * 10) + 1;
var answer = Math.floor(Math.random() * 10) + 1;
num2 = num1 + answer;

q3Out.innerHTML = "What is the difference between " + num2 + " and " + num1;
a3Out.innerHTML = "Answer " + answer;

//Question 4
var q4Out = document.getElementById("question4");
var a4Out = document.getElementById("answer4");

num1 = Math.floor(Math.random() * 15) + 1;
num2 = num1 + answer;
answer = Math.floor(Math.random() * 10) + 5;

q4Out.innerHTML = "What is the perimiter of a rectangle with length " + num2 + " and height " + num1;
a4Out.innerHTML = "Answer " + (2 * num1 + 2 * num2);

//Question 5
var q5Out = document.getElementById("question5");
var a5Out = document.getElementById("answer5");

num1 = (Math.random() * 10 + 0.50).toFixed(2);
answer = Math.floor(Math.random() * 10) + 1;
num2 = (answer * num1).toFixed(2);

q5Out.innerHTML = "An orange costs $" + num1 + " and Billy has $" + num2 + "." +
    " How many oranges can she buy?";
a5Out.innerHTML = "Answer " + answer;