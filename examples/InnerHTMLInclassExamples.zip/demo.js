var output=document.getElementById("output");
output.innerHTML = "Test message";