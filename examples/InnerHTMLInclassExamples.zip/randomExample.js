var ageOut = document.getElementById("age");
var dayOut = document.getElementById("days");
var hourOut = document.getElementById("hours");

var yourAge = Math.floor(Math.random()*200);

ageOut.innerHTML = "You are " + yourAge + 
	" years old.";
dayOut.innerHTML = "You are " + yourAge*365 +
	" days old."
hourOut.innerHTML = "You are " + yourAge*365*24 +
	" hours old."


