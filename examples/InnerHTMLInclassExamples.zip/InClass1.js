var appName = document.getElementById("ppName");
var platform = document.getElementById("platform");
var language = document.getElementById("language");
var javaEnabled = document.getElementById("javaEnabled");


appName.innerHTML = navigator.appName;
platform.innerHTML = navigator.platform;
language.innerHTML = navigator.language;
javaEnabled.innerHTML = navigator.javaEnabled();