//Get the reference to the elements.
var out1 = document.getElementById("demoArea1");
var out2 = document.getElementById("demoArea2");

//Constructor information for output area 1.
var outString1 = "Cookies enabled: " + navigator.cookieEnabled + "<br>" +
    "Browser engine: " + navigator.product;
var outString2 = "<h2>" + document.baseURI + "</h2>";

out1.innerHTML = outString1;
out2.innerHTML = outString2;