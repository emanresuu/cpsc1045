//stores the reference to the timer
//which we need to stop the timer
var timerReference = null;
var phase = 0;
var increment = 0.1;
var canvas = document.getElementById("pendulum");
var ctx = canvas.getContext("2d");

function clearTimer() {
    "use strict";
    //Make sure that we don't have a timer
    if (timerReference !== null) {
        clearInterval(timerReference);
        //set the reference back to null, 
        //indicating no timer
        timerReference = null;
    }
}

function startTimer() {
    "use strict";
    //Make sure we don't have a timer already
    //if we do, don't make a new one
    //or we will have two timers.
    if (timerReference === null) {
        timerReference = setInterval(timerFunc, 33);
    }
}

function stopTimer() {
    "use strict";
    clearTimer();
}
//Does the actual work, for each tick event.
function timerFunc() {
    "use strict";
    ctx.clearRect(0, 0, 400, 400);
    phase = phase + increment; //Increment the phase every clock tick
    var maxAngle = 20; //Maximum angle of swing
    var angle = maxAngle * Math.sin(phase); //Calculate the angle the pendulum should be at


    //Draw stuff
    ctx.save();
    ctx.translate(200, 0);

    //Pit
    ctx.beginPath();
    ctx.ellipse(0, 350, 100, 10, 0, 0, 2 * Math.PI);
    ctx.fill();

    //Pendulum
    ctx.rotate(angle * Math.PI / 180);
    ctx.beginPath();
    ctx.arc(0, 300, 10, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.beginPath();
    ctx.lineTo(0, 0);
    ctx.lineTo(0, 300);
    ctx.stroke();

    ctx.restore();

}