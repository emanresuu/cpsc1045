//stores the reference to the timer
//which we need to stop the timer
var timerReference = null;
var counter = 0;

function clearTimer() {
    "use strict";
    //Make sure that we don't have a timer
    if (timerReference !== null) {
        clearInterval(timerReference);
        //set the reference back to null, 
        //indicating no timer
        timerReference = null;
    }
}

function reset() {
    "use strict";
    var outputElement = document.getElementById("output");
    clearTimer();
    counter = 0;
    outputElement.innerHTML = counter;
}

function startTimer() {
    "use strict";
    //Make sure we don't have a timer already
    //if we do, don't make a new one
    //or we will have two timers.
    if (timerReference === null) {
        timerReference = setInterval(timerFunc, 100);
    }
}

function stopTimer() {
    "use strict";
    clearTimer();
}
//Does the actual work, for each tick event.
function timerFunc() {
    "use strict";
    var outputElement = document.getElementById("output");
    counter += 1;
    outputElement.innerHTML = counter;
}