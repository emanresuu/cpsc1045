function updatePosition(event) {
    "use strict";
    var ctx = document.getElementById("surface").getContext("2d");
    var xPosLabel = document.getElementById("xout");
    var yPosLabel = document.getElementById("yout");
    xPosLabel.innerHTML = event.offsetX;
    yPosLabel.innerHTML = event.offsetY;

    var alpha = 1.0; //Try changing alpha to 0.5
    //var alpha = 20/Math.sqrt(Math.pow(event.offsetX-200,2)+Math.pow(event.offsetY-200,2));
    //Try using the above formula instead of alpha = 1;

    ctx.clearRect(0, 0, 400, 400);

    //Draws, you can have it draw any shape
    ctx.beginPath();
    ctx.lineTo(200, 200);
    ctx.lineTo(alpha * (event.offsetX - 200) + 200, alpha * (event.offsetY - 200) + 200);
    ctx.stroke();
}