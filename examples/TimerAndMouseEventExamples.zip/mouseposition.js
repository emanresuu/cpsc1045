function updatePosition(event) {
    "use strict";

    var xPosLabel = document.getElementById("xout");
    var yPosLabel = document.getElementById("yout");

    xPosLabel.innerHTML = event.offsetX;
    yPosLabel.innerHTML = event.offsetY;
}